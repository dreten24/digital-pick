from typing import Dict, Any
from datetime import datetime
import json

from app.core.database import SessionLocal
from app.models.lead import Lead, LeadSource
from app.schemas.lead import LeadCreate
from app.services.lead_service import LeadService
from app.services.monitoring_service import MonitoringService

class WebhookHandlers:
    def __init__(self):
        self.lead_service = LeadService()
        self.monitoring = MonitoringService()
    
    async def handle_lead_capture(self, data: Dict[str, Any]):
        """Handle generic lead capture webhook"""
        db = SessionLocal()
        try:
            # Extract lead information from webhook data
            lead_data = self._extract_lead_data(data)
            
            if lead_data:
                lead_create = LeadCreate(**lead_data)
                lead = await self.lead_service.create_lead(db, lead_create)
                
                await self.monitoring.log_event(
                    event_type="webhook_lead_captured",
                    event_category="webhooks",
                    title=f"Lead Captured via Webhook: {lead.first_name} {lead.last_name}",
                    description=f"Lead captured from {lead.source.value}",
                    business_id=lead.business_id,
                    metadata={"lead_id": lead.id, "webhook_data": data}
                )
            else:
                await self.monitoring.log_event(
                    event_type="webhook_data_invalid",
                    event_category="webhooks",
                    title="Invalid Webhook Data",
                    description="Could not extract lead data from webhook",
                    severity="warning",
                    metadata={"webhook_data": data}
                )
                
        except Exception as e:
            await self.monitoring.log_event(
                event_type="webhook_error",
                event_category="system",
                title="Webhook Processing Error",
                description=f"Error processing lead capture webhook: {str(e)}",
                severity="error",
                metadata={"webhook_data": data}
            )
        finally:
            db.close()
    
    async def handle_form_submission(self, data: Dict[str, Any]):
        """Handle website form submission webhook"""
        db = SessionLocal()
        try:
            # Extract form data
            form_data = {
                "business_id": data.get("business_id", 1),  # Default business
                "first_name": data.get("first_name", data.get("name", "").split()[0] if data.get("name") else ""),
                "last_name": data.get("last_name", " ".join(data.get("name", "").split()[1:]) if data.get("name") else ""),
                "email": data.get("email"),
                "phone": data.get("phone"),
                "service_address": data.get("address", ""),
                "service_city": data.get("city", ""),
                "service_state": data.get("state", ""),
                "service_zip": data.get("zip", ""),
                "source": LeadSource.WEBSITE,
                "service_type": data.get("service_type", "general"),
                "description": data.get("message", data.get("description", "")),
                "urgency": data.get("urgency", "medium")
            }
            
            # Set preferred date if provided
            if data.get("preferred_date"):
                try:
                    form_data["preferred_date"] = datetime.fromisoformat(data["preferred_date"])
                except:
                    pass
            
            lead_create = LeadCreate(**form_data)
            lead = await self.lead_service.create_lead(db, lead_create)
            
            await self.monitoring.log_event(
                event_type="form_submission_processed",
                event_category="webhooks",
                title=f"Form Submission: {lead.first_name} {lead.last_name}",
                description=f"Website form submission processed",
                business_id=lead.business_id,
                metadata={"lead_id": lead.id, "form_data": data}
            )
            
        except Exception as e:
            await self.monitoring.log_event(
                event_type="form_submission_error",
                event_category="system",
                title="Form Submission Error",
                description=f"Error processing form submission: {str(e)}",
                severity="error",
                metadata={"form_data": data}
            )
        finally:
            db.close()
    
    async def handle_google_ads_lead(self, data: Dict[str, Any]):
        """Handle Google Ads lead webhook"""
        db = SessionLocal()
        try:
            # Process Google Ads lead format
            google_lead = data.get("lead", {})
            
            lead_data = {
                "business_id": data.get("business_id", 1),
                "first_name": google_lead.get("first_name", ""),
                "last_name": google_lead.get("last_name", ""),
                "email": google_lead.get("email"),
                "phone": google_lead.get("phone_number"),
                "service_address": google_lead.get("address", ""),
                "service_city": google_lead.get("city", ""),
                "service_state": google_lead.get("state", ""),
                "service_zip": google_lead.get("postal_code", ""),
                "source": LeadSource.GOOGLE_ADS,
                "service_type": data.get("campaign_name", "google_ads"),
                "description": f"Google Ads lead from campaign: {data.get('campaign_name', '')}",
                "urgency": "high"  # Google Ads leads are typically high priority
            }
            
            lead_create = LeadCreate(**lead_data)
            lead = await self.lead_service.create_lead(db, lead_create)
            
            await self.monitoring.log_event(
                event_type="google_ads_lead_processed",
                event_category="webhooks",
                title=f"Google Ads Lead: {lead.first_name} {lead.last_name}",
                description=f"Google Ads lead from campaign: {data.get('campaign_name', '')}",
                business_id=lead.business_id,
                metadata={"lead_id": lead.id, "campaign": data.get("campaign_name")}
            )
            
        except Exception as e:
            await self.monitoring.log_event(
                event_type="google_ads_webhook_error",
                event_category="system",
                title="Google Ads Webhook Error",
                description=f"Error processing Google Ads webhook: {str(e)}",
                severity="error",
                metadata={"google_ads_data": data}
            )
        finally:
            db.close()
    
    async def handle_facebook_lead(self, data: Dict[str, Any]):
        """Handle Facebook lead ads webhook"""
        db = SessionLocal()
        try:
            # Process Facebook lead format
            entries = data.get("entry", [])
            
            for entry in entries:
                changes = entry.get("changes", [])
                for change in changes:
                    if change.get("field") == "leadgen":
                        leadgen_data = change.get("value", {})
                        # Process the Facebook lead data
                        # This would need to fetch the actual lead data from Facebook API
                        
                        await self.monitoring.log_event(
                            event_type="facebook_lead_received",
                            event_category="webhooks",
                            title="Facebook Lead Received",
                            description="Facebook lead webhook received",
                            metadata={"facebook_data": leadgen_data}
                        )
            
        except Exception as e:
            await self.monitoring.log_event(
                event_type="facebook_webhook_error",
                event_category="system",
                title="Facebook Webhook Error",
                description=f"Error processing Facebook webhook: {str(e)}",
                severity="error",
                metadata={"facebook_data": data}
            )
        finally:
            db.close()
    
    async def handle_payment_update(self, data: Dict[str, Any]):
        """Handle payment webhook (Stripe, etc.)"""
        try:
            event_type = data.get("type")
            
            if event_type == "payment_intent.succeeded":
                # Handle successful payment
                payment_intent = data.get("data", {}).get("object", {})
                
                await self.monitoring.log_event(
                    event_type="payment_received",
                    event_category="payments",
                    title="Payment Received",
                    description=f"Payment of ${payment_intent.get('amount', 0)/100} received",
                    metadata={"payment_intent": payment_intent.get("id")}
                )
                
        except Exception as e:
            await self.monitoring.log_event(
                event_type="payment_webhook_error",
                event_category="system",
                title="Payment Webhook Error",
                description=f"Error processing payment webhook: {str(e)}",
                severity="error",
                metadata={"payment_data": data}
            )
    
    async def handle_status_update(self, data: Dict[str, Any]):
        """Handle generic status update webhook"""
        try:
            await self.monitoring.log_event(
                event_type="status_update_received",
                event_category="webhooks",
                title="Status Update Received",
                description=f"Status update: {data.get('status', 'unknown')}",
                metadata={"update_data": data}
            )
            
        except Exception as e:
            await self.monitoring.log_event(
                event_type="status_webhook_error",
                event_category="system",
                title="Status Webhook Error",
                description=f"Error processing status webhook: {str(e)}",
                severity="error",
                metadata={"status_data": data}
            )
    
    def _extract_lead_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract and normalize lead data from various webhook formats"""
        try:
            # Try to extract common lead fields
            lead_data = {
                "business_id": data.get("business_id", 1),
                "first_name": data.get("firstName", data.get("first_name", "")),
                "last_name": data.get("lastName", data.get("last_name", "")),
                "email": data.get("email"),
                "phone": data.get("phone", data.get("phoneNumber")),
                "service_address": data.get("address", ""),
                "service_city": data.get("city", ""),
                "service_state": data.get("state", ""),
                "service_zip": data.get("zip", data.get("zipCode", "")),
                "source": LeadSource.WEBSITE,  # Default source
                "service_type": data.get("serviceType", data.get("service", "general")),
                "description": data.get("message", data.get("comments", "")),
                "urgency": data.get("urgency", "medium")
            }
            
            # Clean up empty strings
            return {k: v for k, v in lead_data.items() if v}
            
        except Exception:
            return None
