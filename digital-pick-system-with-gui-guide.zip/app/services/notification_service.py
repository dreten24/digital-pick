from typing import Optional, Dict, Any
from datetime import datetime
import asyncio

from app.core.config import settings
from app.models.lead import Lead, LeadStatus
from app.services.monitoring_service import MonitoringService

class NotificationService:
    def __init__(self):
        self.monitoring = MonitoringService()
    
    async def notify_new_lead(self, lead: Lead):
        """Send notifications for a new lead"""
        try:
            # Log the new lead notification
            await self.monitoring.log_event(
                event_type="notification_sent",
                event_category="notifications",
                title=f"New Lead Notification: {lead.first_name} {lead.last_name}",
                description=f"Notification sent for new {lead.service_type} lead from {lead.source.value}",
                business_id=lead.business_id,
                metadata={
                    "lead_id": lead.id,
                    "notification_type": "new_lead",
                    "urgency": lead.urgency
                }
            )
            
            # Here you would integrate with actual notification services:
            # - Send email via SendGrid
            # - Send SMS via Twilio
            # - Send Slack message
            # - Push notification
            
            if lead.urgency == "emergency":
                await self._send_emergency_notifications(lead)
                
        except Exception as e:
            await self.monitoring.log_event(
                event_type="notification_error",
                event_category="system",
                title="Notification Error",
                description=f"Failed to send new lead notification: {str(e)}",
                severity="error",
                business_id=lead.business_id
            )
    
    async def notify_lead_status_change(self, lead: Lead, new_status: LeadStatus):
        """Send notifications for lead status changes"""
        try:
            await self.monitoring.log_event(
                event_type="notification_sent",
                event_category="notifications", 
                title=f"Lead Status Changed: {lead.first_name} {lead.last_name}",
                description=f"Lead status changed to {new_status.value}",
                business_id=lead.business_id,
                metadata={
                    "lead_id": lead.id,
                    "notification_type": "status_change",
                    "new_status": new_status.value
                }
            )
            
        except Exception as e:
            await self.monitoring.log_event(
                event_type="notification_error",
                event_category="system",
                title="Status Change Notification Error",
                description=f"Failed to send status change notification: {str(e)}",
                severity="error",
                business_id=lead.business_id
            )
    
    async def _send_emergency_notifications(self, lead: Lead):
        """Send emergency notifications for high-priority leads"""
        # This would send immediate notifications via multiple channels
        # for emergency/high-priority leads
        await self.monitoring.log_event(
            event_type="emergency_notification",
            event_category="alerts",
            title=f"EMERGENCY LEAD: {lead.first_name} {lead.last_name}",
            description=f"Emergency {lead.service_type} lead requires immediate attention",
            severity="critical",
            business_id=lead.business_id,
            metadata={"lead_id": lead.id}
        )
