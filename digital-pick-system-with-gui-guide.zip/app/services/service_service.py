from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

from app.models.service import Service, ServiceRequest, ServiceStatus
from app.schemas.service import ServiceCreate, ServiceUpdate, ServiceRequestCreate, ServiceRequestUpdate
from app.services.monitoring_service import MonitoringService

class ServiceService:
    def __init__(self):
        self.monitoring = MonitoringService()
    
    # Service Management
    async def create_service(self, db: Session, service_data: ServiceCreate) -> Service:
        """Create a new service offering"""
        service = Service(**service_data.dict())
        db.add(service)
        db.commit()
        db.refresh(service)
        
        await self.monitoring.log_event(
            event_type="service_created",
            event_category="services",
            title=f"New Service Created: {service.name}",
            description=f"Service {service.name} created for {service.category}",
            business_id=service.business_id
        )
        
        return service
    
    async def get_services(
        self,
        db: Session,
        business_id: Optional[int] = None,
        category: Optional[str] = None,
        is_active: Optional[bool] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[Service]:
        """Get services with filtering"""
        query = db.query(Service)
        
        if business_id:
            query = query.filter(Service.business_id == business_id)
        if category:
            query = query.filter(Service.category == category)
        if is_active is not None:
            query = query.filter(Service.is_active == is_active)
        
        return query.offset(skip).limit(limit).all()
    
    async def get_service(self, db: Session, service_id: int) -> Optional[Service]:
        """Get a service by ID"""
        return db.query(Service).filter(Service.id == service_id).first()
    
    async def update_service(
        self, 
        db: Session, 
        service_id: int, 
        service_update: ServiceUpdate
    ) -> Optional[Service]:
        """Update a service"""
        service = db.query(Service).filter(Service.id == service_id).first()
        if not service:
            return None
        
        update_data = service_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(service, field, value)
        
        service.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(service)
        return service
    
    async def delete_service(self, db: Session, service_id: int) -> bool:
        """Delete (deactivate) a service"""
        service = db.query(Service).filter(Service.id == service_id).first()
        if not service:
            return False
        
        service.is_active = False
        service.updated_at = datetime.utcnow()
        db.commit()
        return True
    
    # Service Request Management
    async def create_service_request(
        self, 
        db: Session, 
        request_data: ServiceRequestCreate
    ) -> ServiceRequest:
        """Create a new service request"""
        service_request = ServiceRequest(**request_data.dict())
        db.add(service_request)
        db.commit()
        db.refresh(service_request)
        
        await self.monitoring.log_event(
            event_type="service_request_created",
            event_category="services",
            title="New Service Request Created",
            description=f"Service request created for lead {service_request.lead_id}",
            metadata={"service_request_id": service_request.id}
        )
        
        return service_request
    
    async def get_service_requests(
        self,
        db: Session,
        business_id: Optional[int] = None,
        status: Optional[ServiceStatus] = None,
        priority: Optional[str] = None,
        assigned_team: Optional[str] = None,
        scheduled_after: Optional[datetime] = None,
        scheduled_before: Optional[datetime] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[ServiceRequest]:
        """Get service requests with filtering"""
        query = db.query(ServiceRequest)
        
        if business_id:
            query = query.join(ServiceRequest.lead).filter(
                ServiceRequest.lead.has(business_id=business_id)
            )
        if status:
            query = query.filter(ServiceRequest.status == status)
        if priority:
            query = query.filter(ServiceRequest.priority == priority)
        if assigned_team:
            query = query.filter(ServiceRequest.assigned_team == assigned_team)
        if scheduled_after:
            query = query.filter(ServiceRequest.scheduled_start >= scheduled_after)
        if scheduled_before:
            query = query.filter(ServiceRequest.scheduled_start <= scheduled_before)
        
        return query.order_by(ServiceRequest.scheduled_start).offset(skip).limit(limit).all()
    
    async def get_service_request(self, db: Session, request_id: int) -> Optional[ServiceRequest]:
        """Get a service request by ID"""
        return db.query(ServiceRequest).filter(ServiceRequest.id == request_id).first()
    
    async def update_service_request(
        self, 
        db: Session, 
        request_id: int, 
        request_update: ServiceRequestUpdate
    ) -> Optional[ServiceRequest]:
        """Update a service request"""
        service_request = db.query(ServiceRequest).filter(ServiceRequest.id == request_id).first()
        if not service_request:
            return None
        
        old_status = service_request.status
        update_data = request_update.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            setattr(service_request, field, value)
        
        service_request.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(service_request)
        
        # Log status change
        if request_update.status and request_update.status != old_status:
            await self.monitoring.log_event(
                event_type="service_status_changed",
                event_category="services",
                title="Service Status Changed",
                description=f"Service status changed from {old_status.value} to {request_update.status.value}",
                metadata={"service_request_id": request_id}
            )
        
        return service_request
    
    async def start_service(
        self, 
        db: Session, 
        request_id: int, 
        start_time: Optional[datetime] = None
    ) -> bool:
        """Mark a service as started"""
        service_request = db.query(ServiceRequest).filter(ServiceRequest.id == request_id).first()
        if not service_request:
            return False
        
        service_request.status = ServiceStatus.IN_PROGRESS
        service_request.actual_start = start_time or datetime.utcnow()
        db.commit()
        
        await self.monitoring.log_event(
            event_type="service_started",
            event_category="services",
            title="Service Started",
            description=f"Service request {request_id} started",
            metadata={"service_request_id": request_id}
        )
        
        return True
    
    async def complete_service(
        self, 
        db: Session, 
        request_id: int, 
        completion_data: Dict[str, Any]
    ) -> bool:
        """Mark a service as completed"""
        service_request = db.query(ServiceRequest).filter(ServiceRequest.id == request_id).first()
        if not service_request:
            return False
        
        service_request.status = ServiceStatus.COMPLETED
        service_request.actual_end = datetime.utcnow()
        
        # Update completion data
        for field, value in completion_data.items():
            if hasattr(service_request, field):
                setattr(service_request, field, value)
        
        db.commit()
        
        await self.monitoring.log_event(
            event_type="service_completed",
            event_category="services",
            title="Service Completed",
            description=f"Service request {request_id} completed",
            metadata={"service_request_id": request_id}
        )
        
        return True
    
    async def get_service_timeline(self, db: Session, request_id: int) -> Optional[Dict]:
        """Get timeline of a service request"""
        service_request = db.query(ServiceRequest).filter(ServiceRequest.id == request_id).first()
        if not service_request:
            return None
        
        timeline = []
        
        # Add creation
        timeline.append({
            "timestamp": service_request.created_at,
            "type": "created",
            "description": "Service request created"
        })
        
        # Add scheduled
        if service_request.scheduled_start:
            timeline.append({
                "timestamp": service_request.scheduled_start,
                "type": "scheduled",
                "description": f"Service scheduled with {service_request.assigned_team or 'team'}"
            })
        
        # Add started
        if service_request.actual_start:
            timeline.append({
                "timestamp": service_request.actual_start,
                "type": "started",
                "description": "Service started"
            })
        
        # Add completed
        if service_request.actual_end:
            timeline.append({
                "timestamp": service_request.actual_end,
                "type": "completed",
                "description": "Service completed"
            })
        
        return {
            "service_request_id": request_id,
            "timeline": sorted(timeline, key=lambda x: x["timestamp"])
        }
    
    async def get_performance_analytics(
        self, 
        db: Session, 
        business_id: Optional[int] = None, 
        days: int = 30
    ) -> Dict:
        """Get service performance analytics"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        query = db.query(ServiceRequest)
        if business_id:
            query = query.join(ServiceRequest.lead).filter(
                ServiceRequest.lead.has(business_id=business_id)
            )
        
        query = query.filter(ServiceRequest.created_at >= start_date)
        
        total_requests = query.count()
        completed_requests = query.filter(ServiceRequest.status == ServiceStatus.COMPLETED).count()
        
        completion_rate = (completed_requests / total_requests * 100) if total_requests > 0 else 0
        
        # Average completion time
        completed_query = query.filter(
            ServiceRequest.status == ServiceStatus.COMPLETED,
            ServiceRequest.actual_start.isnot(None),
            ServiceRequest.actual_end.isnot(None)
        )
        
        avg_duration = db.query(
            func.avg(
                func.julianday(ServiceRequest.actual_end) - 
                func.julianday(ServiceRequest.actual_start)
            )
        ).filter(
            ServiceRequest.id.in_(completed_query.subquery().select())
        ).scalar() or 0
        
        return {
            "period_days": days,
            "total_requests": total_requests,
            "completed_requests": completed_requests,
            "completion_rate": completion_rate,
            "average_duration_days": avg_duration
        }
    
    async def get_revenue_analytics(
        self, 
        db: Session, 
        business_id: Optional[int] = None, 
        days: int = 30,
        service_category: Optional[str] = None
    ) -> Dict:
        """Get service revenue analytics"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        query = db.query(ServiceRequest).filter(
            ServiceRequest.status == ServiceStatus.COMPLETED,
            ServiceRequest.actual_end >= start_date
        )
        
        if business_id:
            query = query.join(ServiceRequest.lead).filter(
                ServiceRequest.lead.has(business_id=business_id)
            )
        
        if service_category:
            query = query.join(ServiceRequest.service).filter(
                ServiceRequest.service.has(category=service_category)
            )
        
        total_revenue = db.query(func.sum(ServiceRequest.final_price)).filter(
            ServiceRequest.id.in_(query.subquery().select())
        ).scalar() or 0
        
        avg_service_value = db.query(func.avg(ServiceRequest.final_price)).filter(
            ServiceRequest.id.in_(query.subquery().select())
        ).scalar() or 0
        
        return {
            "period_days": days,
            "service_category": service_category,
            "total_revenue": total_revenue,
            "average_service_value": avg_service_value,
            "completed_services": query.count()
        }
    
    async def get_daily_schedule(
        self, 
        db: Session, 
        business_id: int, 
        team: Optional[str] = None
    ) -> List[Dict]:
        """Get today's service schedule"""
        today = datetime.utcnow().date()
        
        query = db.query(ServiceRequest).filter(
            func.date(ServiceRequest.scheduled_start) == today,
            ServiceRequest.lead.has(business_id=business_id)
        )
        
        if team:
            query = query.filter(ServiceRequest.assigned_team == team)
        
        requests = query.order_by(ServiceRequest.scheduled_start).all()
        
        return [
            {
                "id": req.id,
                "lead_id": req.lead_id,
                "scheduled_start": req.scheduled_start,
                "scheduled_end": req.scheduled_end,
                "status": req.status.value,
                "assigned_team": req.assigned_team,
                "priority": req.priority
            }
            for req in requests
        ]
    
    async def get_weekly_schedule(
        self, 
        db: Session, 
        business_id: int, 
        team: Optional[str] = None
    ) -> List[Dict]:
        """Get this week's service schedule"""
        today = datetime.utcnow().date()
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=6)
        
        query = db.query(ServiceRequest).filter(
            func.date(ServiceRequest.scheduled_start) >= week_start,
            func.date(ServiceRequest.scheduled_start) <= week_end,
            ServiceRequest.lead.has(business_id=business_id)
        )
        
        if team:
            query = query.filter(ServiceRequest.assigned_team == team)
        
        requests = query.order_by(ServiceRequest.scheduled_start).all()
        
        return [
            {
                "id": req.id,
                "lead_id": req.lead_id,
                "scheduled_start": req.scheduled_start,
                "scheduled_end": req.scheduled_end,
                "status": req.status.value,
                "assigned_team": req.assigned_team,
                "priority": req.priority
            }
            for req in requests
        ]
