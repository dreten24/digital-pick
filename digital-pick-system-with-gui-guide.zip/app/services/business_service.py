from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional
from datetime import datetime, timedelta

from app.models.business import Business
from app.models.lead import Lead, LeadStatus
from app.models.service import ServiceRequest, ServiceStatus
from app.schemas.business import BusinessCreate, BusinessUpdate
from app.services.monitoring_service import MonitoringService

class BusinessService:
    def __init__(self):
        self.monitoring = MonitoringService()
    
    async def create_business(self, db: Session, business_data: BusinessCreate) -> Business:
        """Create a new business account"""
        # Check if email already exists
        existing = db.query(Business).filter(Business.email == business_data.email).first()
        if existing:
            raise ValueError("Business with this email already exists")
        
        business = Business(**business_data.dict())
        db.add(business)
        db.commit()
        db.refresh(business)
        
        # Log business creation event
        await self.monitoring.log_event(
            event_type="business_created",
            event_category="business",
            title=f"New Business Created: {business.name}",
            description=f"Business {business.name} ({business.business_type}) created",
            business_id=business.id
        )
        
        return business
    
    async def get_businesses(
        self, 
        db: Session, 
        skip: int = 0, 
        limit: int = 100,
        is_active: Optional[bool] = None,
        business_type: Optional[str] = None
    ) -> List[Business]:
        """Get businesses with filtering"""
        query = db.query(Business)
        
        if is_active is not None:
            query = query.filter(Business.is_active == is_active)
        
        if business_type:
            query = query.filter(Business.business_type == business_type)
        
        return query.offset(skip).limit(limit).all()
    
    async def get_business(self, db: Session, business_id: int) -> Optional[Business]:
        """Get a specific business by ID"""
        return db.query(Business).filter(Business.id == business_id).first()
    
    async def update_business(
        self, 
        db: Session, 
        business_id: int, 
        business_update: BusinessUpdate
    ) -> Optional[Business]:
        """Update a business"""
        business = db.query(Business).filter(Business.id == business_id).first()
        if not business:
            return None
        
        update_data = business_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(business, field, value)
        
        business.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(business)
        
        # Log business update event
        await self.monitoring.log_event(
            event_type="business_updated",
            event_category="business",
            title=f"Business Updated: {business.name}",
            business_id=business.id
        )
        
        return business
    
    async def delete_business(self, db: Session, business_id: int) -> bool:
        """Delete (deactivate) a business"""
        business = db.query(Business).filter(Business.id == business_id).first()
        if not business:
            return False
        
        business.is_active = False
        business.updated_at = datetime.utcnow()
        db.commit()
        
        # Log business deactivation event
        await self.monitoring.log_event(
            event_type="business_deactivated",
            event_category="business",
            title=f"Business Deactivated: {business.name}",
            business_id=business.id
        )
        
        return True
    
    async def get_business_stats(self, db: Session, business_id: int) -> Optional[dict]:
        """Get comprehensive business statistics"""
        business = db.query(Business).filter(Business.id == business_id).first()
        if not business:
            return None
        
        # Lead statistics
        total_leads = db.query(Lead).filter(Lead.business_id == business_id).count()
        new_leads = db.query(Lead).filter(
            Lead.business_id == business_id,
            Lead.status == LeadStatus.NEW
        ).count()
        
        # Service statistics
        total_services = db.query(ServiceRequest).filter(
            ServiceRequest.lead.has(business_id=business_id)
        ).count()
        completed_services = db.query(ServiceRequest).filter(
            ServiceRequest.lead.has(business_id=business_id),
            ServiceRequest.status == ServiceStatus.COMPLETED
        ).count()
        
        # Revenue statistics
        total_revenue = db.query(func.sum(ServiceRequest.final_price)).filter(
            ServiceRequest.lead.has(business_id=business_id),
            ServiceRequest.status == ServiceStatus.COMPLETED
        ).scalar() or 0
        
        return {
            "business_info": {
                "id": business.id,
                "name": business.name,
                "type": business.business_type,
                "created_at": business.created_at,
                "is_active": business.is_active
            },
            "lead_stats": {
                "total_leads": total_leads,
                "new_leads": new_leads,
                "conversion_rate": (completed_services / total_leads * 100) if total_leads > 0 else 0
            },
            "service_stats": {
                "total_services": total_services,
                "completed_services": completed_services,
                "completion_rate": (completed_services / total_services * 100) if total_services > 0 else 0
            },
            "revenue_stats": {
                "total_revenue": total_revenue,
                "average_service_value": (total_revenue / completed_services) if completed_services > 0 else 0
            }
        }
    
    async def get_leads_summary(
        self, 
        db: Session, 
        business_id: int, 
        days: int = 30
    ) -> dict:
        """Get lead summary for a business"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Lead counts by status
        lead_counts = db.query(
            Lead.status, func.count(Lead.id)
        ).filter(
            Lead.business_id == business_id,
            Lead.created_at >= start_date
        ).group_by(Lead.status).all()
        
        # Lead sources
        lead_sources = db.query(
            Lead.source, func.count(Lead.id)
        ).filter(
            Lead.business_id == business_id,
            Lead.created_at >= start_date
        ).group_by(Lead.source).all()
        
        # Daily lead trend
        daily_leads = db.query(
            func.date(Lead.created_at).label('date'),
            func.count(Lead.id).label('count')
        ).filter(
            Lead.business_id == business_id,
            Lead.created_at >= start_date
        ).group_by(func.date(Lead.created_at)).all()
        
        return {
            "period_days": days,
            "status_breakdown": dict(lead_counts),
            "source_breakdown": dict(lead_sources),
            "daily_trend": [{"date": str(date), "count": count} for date, count in daily_leads]
        }
    
    async def get_revenue_summary(
        self, 
        db: Session, 
        business_id: int, 
        days: int = 30
    ) -> dict:
        """Get revenue summary for a business"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Total revenue
        total_revenue = db.query(func.sum(ServiceRequest.final_price)).filter(
            ServiceRequest.lead.has(business_id=business_id),
            ServiceRequest.status == ServiceStatus.COMPLETED,
            ServiceRequest.actual_end >= start_date
        ).scalar() or 0
        
        # Daily revenue trend
        daily_revenue = db.query(
            func.date(ServiceRequest.actual_end).label('date'),
            func.sum(ServiceRequest.final_price).label('revenue')
        ).filter(
            ServiceRequest.lead.has(business_id=business_id),
            ServiceRequest.status == ServiceStatus.COMPLETED,
            ServiceRequest.actual_end >= start_date
        ).group_by(func.date(ServiceRequest.actual_end)).all()
        
        # Average service value
        avg_service_value = db.query(func.avg(ServiceRequest.final_price)).filter(
            ServiceRequest.lead.has(business_id=business_id),
            ServiceRequest.status == ServiceStatus.COMPLETED,
            ServiceRequest.actual_end >= start_date
        ).scalar() or 0
        
        return {
            "period_days": days,
            "total_revenue": total_revenue,
            "average_service_value": avg_service_value,
            "daily_revenue": [
                {"date": str(date), "revenue": float(revenue)} 
                for date, revenue in daily_revenue
            ]
        }
