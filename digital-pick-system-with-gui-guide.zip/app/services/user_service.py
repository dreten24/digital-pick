from sqlalchemy.orm import Session
from typing import List, Optional
from passlib.context import CryptContext

from app.models.user import User
from app.schemas.user import UserCreate, UserUpdate

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class UserService:
    
    def _hash_password(self, password: str) -> str:
        """Hash a password"""
        return pwd_context.hash(password)
    
    async def create_user(self, db: Session, user_data: UserCreate) -> User:
        """Create a new user"""
        # Check if email already exists
        existing = db.query(User).filter(User.email == user_data.email).first()
        if existing:
            raise ValueError("User with this email already exists")
        
        # Hash the password
        hashed_password = self._hash_password(user_data.password)
        
        # Create user
        user_dict = user_data.dict()
        del user_dict['password']
        user = User(**user_dict, hashed_password=hashed_password)
        
        db.add(user)
        db.commit()
        db.refresh(user)
        return user
    
    async def get_users(
        self, 
        db: Session, 
        business_id: Optional[int] = None,
        is_active: Optional[bool] = None,
        role: Optional[str] = None
    ) -> List[User]:
        """Get users with filtering"""
        query = db.query(User)
        
        if business_id:
            query = query.filter(User.business_id == business_id)
        if is_active is not None:
            query = query.filter(User.is_active == is_active)
        if role:
            query = query.filter(User.role == role)
        
        return query.all()
    
    async def get_user(self, db: Session, user_id: int) -> Optional[User]:
        """Get a user by ID"""
        return db.query(User).filter(User.id == user_id).first()
    
    async def update_user(
        self, 
        db: Session, 
        user_id: int, 
        user_update: UserUpdate
    ) -> Optional[User]:
        """Update a user"""
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return None
        
        update_data = user_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(user, field, value)
        
        db.commit()
        db.refresh(user)
        return user
    
    async def deactivate_user(self, db: Session, user_id: int) -> bool:
        """Deactivate a user"""
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return False
        
        user.is_active = False
        db.commit()
        return True
    
    async def activate_user(self, db: Session, user_id: int) -> bool:
        """Activate a user"""
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return False
        
        user.is_active = True
        db.commit()
        return True
