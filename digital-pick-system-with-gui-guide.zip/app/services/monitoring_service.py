from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import asyncio
import json

from app.models.monitoring import MonitoringEvent, SystemMetric
from app.schemas.monitoring import MonitoringEventCreate, SystemMetricCreate
from app.core.database import SessionLocal

class MonitoringService:
    def __init__(self):
        self.is_running = False
        self.monitoring_task = None
    
    async def start(self):
        """Start the monitoring service"""
        self.is_running = True
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
    
    async def stop(self):
        """Stop the monitoring service"""
        self.is_running = False
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.is_running:
            try:
                await self._collect_system_metrics()
                await self._check_alerts()
                await asyncio.sleep(300)  # Run every 5 minutes
            except asyncio.CancelledError:
                break
            except Exception as e:
                await self.log_event(
                    event_type="monitoring_error",
                    event_category="system",
                    title="Monitoring Error",
                    description=f"Error in monitoring loop: {str(e)}",
                    severity="error"
                )
                await asyncio.sleep(60)  # Wait 1 minute before retry
    
    async def log_event(
        self,
        event_type: str,
        event_category: str,
        title: str,
        description: Optional[str] = None,
        severity: str = "info",
        business_id: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        source_module: Optional[str] = None,
        source_function: Optional[str] = None
    ):
        """Log a monitoring event"""
        db = SessionLocal()
        try:
            event = MonitoringEvent(
                business_id=business_id,
                event_type=event_type,
                event_category=event_category,
                title=title,
                description=description,
                severity=severity,
                metadata=metadata,
                source_module=source_module,
                source_function=source_function
            )
            db.add(event)
            db.commit()
            
        finally:
            db.close()
    
    async def record_metric(
        self,
        metric_name: str,
        metric_type: str,
        metric_category: str,
        value: float,
        business_id: Optional[int] = None,
        unit: Optional[str] = None,
        tags: Optional[Dict[str, Any]] = None,
        period_start: Optional[datetime] = None,
        period_end: Optional[datetime] = None,
        period_type: str = "point"
    ):
        """Record a system metric"""
        db = SessionLocal()
        try:
            metric = SystemMetric(
                business_id=business_id,
                metric_name=metric_name,
                metric_type=metric_type,
                metric_category=metric_category,
                value=value,
                unit=unit,
                tags=tags,
                period_start=period_start,
                period_end=period_end,
                period_type=period_type
            )
            db.add(metric)
            db.commit()
        finally:
            db.close()
    
    async def get_system_health(self) -> dict:
        """Get overall system health status"""
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow(),
            "monitoring_active": self.is_running
        }
