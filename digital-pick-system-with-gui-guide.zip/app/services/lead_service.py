from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional
from datetime import datetime, timedelta

from app.models.lead import Lead, LeadStatus, LeadSource, LeadActivity
from app.models.service import ServiceRequest
from app.schemas.lead import LeadCreate, LeadUpdate, LeadActivityCreate
from app.services.monitoring_service import MonitoringService

class LeadService:
    def __init__(self):
        self.monitoring = MonitoringService()
    
    async def create_lead(self, db: Session, lead_data: LeadCreate) -> Lead:
        """Create a new lead"""
        lead = Lead(**lead_data.dict())
        lead.first_contact_date = datetime.utcnow()
        db.add(lead)
        db.commit()
        db.refresh(lead)
        
        # Log lead creation event
        await self.monitoring.log_event(
            event_type="lead_created",
            event_category="leads",
            title=f"New Lead: {lead.first_name} {lead.last_name}",
            description=f"Lead for {lead.service_type} from {lead.source.value}",
            business_id=lead.business_id,
            metadata={"lead_id": lead.id, "source": lead.source.value}
        )
        
        # Record metric
        await self.monitoring.record_metric(
            metric_name="leads_created",
            metric_type="counter",
            metric_category="leads",
            value=1,
            business_id=lead.business_id,
            tags={"source": lead.source.value, "service_type": lead.service_type}
        )
        
        return lead
    
    async def get_leads(
        self,
        db: Session,
        business_id: Optional[int] = None,
        status: Optional[LeadStatus] = None,
        source: Optional[LeadSource] = None,
        urgency: Optional[str] = None,
        is_priority: Optional[bool] = None,
        created_after: Optional[datetime] = None,
        created_before: Optional[datetime] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[Lead]:
        """Get leads with comprehensive filtering"""
        query = db.query(Lead)
        
        if business_id:
            query = query.filter(Lead.business_id == business_id)
        if status:
            query = query.filter(Lead.status == status)
        if source:
            query = query.filter(Lead.source == source)
        if urgency:
            query = query.filter(Lead.urgency == urgency)
        if is_priority is not None:
            query = query.filter(Lead.is_priority == is_priority)
        if created_after:
            query = query.filter(Lead.created_at >= created_after)
        if created_before:
            query = query.filter(Lead.created_at <= created_before)
        
        return query.order_by(Lead.created_at.desc()).offset(skip).limit(limit).all()
    
    async def get_lead(self, db: Session, lead_id: int) -> Optional[Lead]:
        """Get a specific lead by ID"""
        return db.query(Lead).filter(Lead.id == lead_id).first()
    
    async def update_lead(
        self, 
        db: Session, 
        lead_id: int, 
        lead_update: LeadUpdate
    ) -> Optional[Lead]:
        """Update a lead"""
        lead = db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            return None
        
        old_status = lead.status
        update_data = lead_update.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            setattr(lead, field, value)
        
        lead.updated_at = datetime.utcnow()
        
        # Update last contact date if status changed
        if lead_update.status and lead_update.status != old_status:
            lead.last_contact_date = datetime.utcnow()
        
        db.commit()
        db.refresh(lead)
        
        # Log status change
        if lead_update.status and lead_update.status != old_status:
            await self.monitoring.log_event(
                event_type="lead_status_changed",
                event_category="leads",
                title=f"Lead Status Changed: {lead.first_name} {lead.last_name}",
                description=f"Status changed from {old_status.value} to {lead_update.status.value}",
                business_id=lead.business_id,
                metadata={"lead_id": lead.id, "old_status": old_status.value, "new_status": lead_update.status.value}
            )
        
        return lead
    
    async def delete_lead(self, db: Session, lead_id: int) -> bool:
        """Delete a lead"""
        lead = db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            return False
        
        db.delete(lead)
        db.commit()
        
        # Log lead deletion
        await self.monitoring.log_event(
            event_type="lead_deleted",
            event_category="leads",
            title=f"Lead Deleted: {lead.first_name} {lead.last_name}",
            business_id=lead.business_id,
            metadata={"lead_id": lead_id}
        )
        
        return True
    
    async def create_activity(
        self, 
        db: Session, 
        activity_data: LeadActivityCreate
    ) -> LeadActivity:
        """Add an activity to a lead"""
        activity = LeadActivity(**activity_data.dict())
        db.add(activity)
        db.commit()
        db.refresh(activity)
        
        # Update lead's last contact date
        lead = db.query(Lead).filter(Lead.id == activity.lead_id).first()
        if lead:
            lead.last_contact_date = datetime.utcnow()
            db.commit()
        
        return activity
    
    async def get_activities(self, db: Session, lead_id: int) -> List[LeadActivity]:
        """Get all activities for a lead"""
        return db.query(LeadActivity).filter(
            LeadActivity.lead_id == lead_id
        ).order_by(LeadActivity.completed_at.desc()).all()
    
    async def convert_to_service(
        self,
        db: Session,
        lead_id: int,
        service_id: int,
        quoted_amount: Optional[float] = None,
        scheduled_date: Optional[datetime] = None
    ) -> Optional[int]:
        """Convert a lead to a service request"""
        lead = db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            return None
        
        # Update lead status
        lead.status = LeadStatus.SCHEDULED
        lead.quoted_amount = quoted_amount
        lead.scheduled_date = scheduled_date
        
        # Create service request
        service_request = ServiceRequest(
            lead_id=lead_id,
            service_id=service_id,
            quoted_price=quoted_amount,
            scheduled_start=scheduled_date
        )
        
        db.add(service_request)
        db.commit()
        db.refresh(service_request)
        
        # Log conversion
        await self.monitoring.log_event(
            event_type="lead_converted",
            event_category="leads",
            title=f"Lead Converted: {lead.first_name} {lead.last_name}",
            description=f"Lead converted to service request",
            business_id=lead.business_id,
            metadata={"lead_id": lead_id, "service_request_id": service_request.id}
        )
        
        # Record conversion metric
        await self.monitoring.record_metric(
            metric_name="leads_converted",
            metric_type="counter",
            metric_category="conversion",
            value=1,
            business_id=lead.business_id
        )
        
        return service_request.id
    
    async def get_lead_timeline(self, db: Session, lead_id: int) -> Optional[dict]:
        """Get complete timeline of a lead"""
        lead = db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            return None
        
        activities = db.query(LeadActivity).filter(
            LeadActivity.lead_id == lead_id
        ).order_by(LeadActivity.completed_at).all()
        
        timeline = []
        
        # Add lead creation
        timeline.append({
            "timestamp": lead.created_at,
            "type": "lead_created",
            "description": f"Lead created from {lead.source.value}",
            "details": {
                "source": lead.source.value,
                "service_type": lead.service_type
            }
        })
        
        # Add activities
        for activity in activities:
            timeline.append({
                "timestamp": activity.completed_at,
                "type": "activity",
                "description": f"{activity.activity_type}: {activity.description}",
                "details": {
                    "activity_type": activity.activity_type,
                    "outcome": activity.outcome,
                    "created_by": activity.created_by
                }
            })
        
        # Add status changes (would need additional tracking for this)
        
        return {
            "lead_id": lead_id,
            "timeline": sorted(timeline, key=lambda x: x["timestamp"])
        }
    
    async def schedule_follow_up(
        self,
        db: Session,
        lead_id: int,
        follow_up_date: datetime,
        notes: Optional[str] = None
    ) -> bool:
        """Schedule a follow-up for a lead"""
        lead = db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            return False
        
        lead.follow_up_date = follow_up_date
        
        # Create activity for follow-up scheduling
        activity = LeadActivity(
            lead_id=lead_id,
            activity_type="follow_up_scheduled",
            description=f"Follow-up scheduled for {follow_up_date.strftime('%Y-%m-%d %H:%M')}",
            outcome="scheduled",
            scheduled_at=follow_up_date,
            created_by="system"
        )
        
        if notes:
            activity.description += f". Notes: {notes}"
        
        db.add(activity)
        db.commit()
        
        return True
    
    async def get_conversion_analytics(
        self, 
        db: Session, 
        business_id: Optional[int] = None, 
        days: int = 30
    ) -> dict:
        """Get lead conversion analytics"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        query = db.query(Lead)
        if business_id:
            query = query.filter(Lead.business_id == business_id)
        query = query.filter(Lead.created_at >= start_date)
        
        total_leads = query.count()
        converted_leads = query.filter(Lead.status.in_([
            LeadStatus.SCHEDULED, LeadStatus.IN_PROGRESS, LeadStatus.COMPLETED
        ])).count()
        
        conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
        
        # Conversion by source
        source_conversion = db.query(
            Lead.source,
            func.count(Lead.id).label('total'),
            func.sum(
                func.case(
                    [(Lead.status.in_([LeadStatus.SCHEDULED, LeadStatus.IN_PROGRESS, LeadStatus.COMPLETED]), 1)],
                    else_=0
                )
            ).label('converted')
        ).filter(Lead.created_at >= start_date)
        
        if business_id:
            source_conversion = source_conversion.filter(Lead.business_id == business_id)
        
        source_conversion = source_conversion.group_by(Lead.source).all()
        
        return {
            "period_days": days,
            "total_leads": total_leads,
            "converted_leads": converted_leads,
            "conversion_rate": conversion_rate,
            "source_breakdown": [
                {
                    "source": source.value,
                    "total": total,
                    "converted": converted,
                    "conversion_rate": (converted / total * 100) if total > 0 else 0
                }
                for source, total, converted in source_conversion
            ]
        }
    
    async def get_source_analytics(
        self, 
        db: Session, 
        business_id: Optional[int] = None, 
        days: int = 30
    ) -> dict:
        """Get lead source performance analytics"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        query = db.query(
            Lead.source,
            func.count(Lead.id).label('count'),
            func.avg(Lead.estimated_value).label('avg_value')
        ).filter(Lead.created_at >= start_date)
        
        if business_id:
            query = query.filter(Lead.business_id == business_id)
        
        results = query.group_by(Lead.source).all()
        
        return {
            "period_days": days,
            "sources": [
                {
                    "source": source.value,
                    "lead_count": count,
                    "average_value": float(avg_value) if avg_value else 0
                }
                for source, count, avg_value in results
            ]
        }
