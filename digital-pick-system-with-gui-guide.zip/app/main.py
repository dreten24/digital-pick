from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer
from contextlib import asynccontextmanager
import uvicorn

from app.core.config import settings
from app.core.database import Base, engine
from app.api.routes import router as api_router
from app.monitoring.monitor import MonitoringService
from app.services.notification_service import NotificationService

# Initialize monitoring and services
monitoring_service = MonitoringService()
notification_service = NotificationService()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    Base.metadata.create_all(bind=engine)
    
    # Initialize monitoring
    if settings.enable_monitoring:
        await monitoring_service.start()
    
    # Log startup event
    await monitoring_service.log_event(
        event_type="system_startup",
        event_category="system",
        title="Digital Pick System Started",
        description=f"System started successfully on version {settings.version}"
    )
    
    yield
    
    # Shutdown
    if settings.enable_monitoring:
        await monitoring_service.stop()

# Create FastAPI app
app = FastAPI(
    title=settings.app_name,
    version=settings.version,
    description="Comprehensive backend monitoring system for home service businesses",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(api_router, prefix=settings.api_prefix)

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "version": settings.version,
        "app_name": settings.app_name,
        "monitoring_enabled": settings.enable_monitoring
    }

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": f"Welcome to {settings.app_name}",
        "version": settings.version,
        "docs_url": "/docs",
        "health_check": "/health"
    }

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level="info"
    )
