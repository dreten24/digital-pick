from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, Float, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base

class MonitoringEvent(Base):
    __tablename__ = "monitoring_events"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id"))
    
    # Event details
    event_type = Column(String, nullable=False)  # lead_created, service_completed, etc
    event_category = Column(String, nullable=False)  # leads, services, system, error
    severity = Column(String, default="info")  # debug, info, warning, error, critical
    
    # Event data
    title = Column(String, nullable=False)
    description = Column(Text)
    metadata = Column(JSON)  # Additional event data
    
    # Source tracking
    source_module = Column(String)
    source_function = Column(String)
    
    # User context
    user_id = Column(Integer)
    ip_address = Column(String)
    user_agent = Column(String)
    
    # Resolution
    is_resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime)
    resolved_by = Column(String)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    business = relationship("Business")

class SystemMetric(Base):
    __tablename__ = "system_metrics"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id"))
    
    # Metric details
    metric_name = Column(String, nullable=False)
    metric_type = Column(String, nullable=False)  # counter, gauge, histogram
    metric_category = Column(String, nullable=False)  # leads, conversion, revenue, system
    
    # Metric data
    value = Column(Float, nullable=False)
    unit = Column(String)
    tags = Column(JSON)  # Additional metric tags/dimensions
    
    # Time period
    period_start = Column(DateTime)
    period_end = Column(DateTime)
    period_type = Column(String, default="point")  # point, hour, day, week, month
    
    # Timestamps
    recorded_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    business = relationship("Business")
