from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base

class Business(Base):
    __tablename__ = "businesses"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, index=True)
    business_type = Column(String, nullable=False)  # junk_removal, roofing, plumbing, etc
    email = Column(String, unique=True, index=True, nullable=False)
    phone = Column(String, nullable=False)
    address = Column(Text)
    city = Column(String)
    state = Column(String)
    zip_code = Column(String)
    
    # Business details
    website = Column(String)
    description = Column(Text)
    logo_url = Column(String)
    
    # Service area
    service_radius = Column(Float, default=25.0)  # miles
    
    # Status
    is_active = Column(Boolean, default=True)
    subscription_status = Column(String, default="trial")  # trial, active, suspended
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    leads = relationship("Lead", back_populates="business")
    services = relationship("Service", back_populates="business")
    users = relationship("User", back_populates="business")
