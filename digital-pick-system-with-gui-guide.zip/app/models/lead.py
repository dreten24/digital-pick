from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, Float, ForeignKey, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base
import enum

class LeadSource(enum.Enum):
    WEBSITE = "website"
    GOOGLE_ADS = "google_ads"
    FACEBOOK = "facebook"
    REFERRAL = "referral"
    PHONE_CALL = "phone_call"
    EMAIL = "email"
    WALK_IN = "walk_in"
    OTHER = "other"

class LeadStatus(enum.Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    QUOTED = "quoted"
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    LOST = "lost"

class Lead(Base):
    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id"), nullable=False)
    
    # Lead information
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    email = Column(String, index=True)
    phone = Column(String, nullable=False)
    
    # Service location
    service_address = Column(Text, nullable=False)
    service_city = Column(String, nullable=False)
    service_state = Column(String, nullable=False)
    service_zip = Column(String, nullable=False)
    
    # Lead details
    source = Column(Enum(LeadSource), nullable=False)
    status = Column(Enum(LeadStatus), default=LeadStatus.NEW)
    service_type = Column(String, nullable=False)  # What service they need
    description = Column(Text)  # Details about the job
    urgency = Column(String, default="medium")  # low, medium, high, emergency
    
    # Estimated value
    estimated_value = Column(Float)
    quoted_amount = Column(Float)
    final_amount = Column(Float)
    
    # Scheduling
    preferred_date = Column(DateTime)
    scheduled_date = Column(DateTime)
    completed_date = Column(DateTime)
    
    # Tracking
    first_contact_date = Column(DateTime)
    last_contact_date = Column(DateTime)
    follow_up_date = Column(DateTime)
    
    # Flags
    is_priority = Column(Boolean, default=False)
    is_recurring_customer = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    business = relationship("Business", back_populates="leads")
    activities = relationship("LeadActivity", back_populates="lead")
    service_requests = relationship("ServiceRequest", back_populates="lead")

class LeadActivity(Base):
    __tablename__ = "lead_activities"

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    
    activity_type = Column(String, nullable=False)  # call, email, text, meeting, note
    description = Column(Text, nullable=False)
    outcome = Column(String)  # connected, voicemail, no_answer, etc
    
    # Contact info
    contact_method = Column(String)
    duration_minutes = Column(Integer)
    
    # Scheduling
    scheduled_at = Column(DateTime)
    completed_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # User tracking
    created_by = Column(String)  # User who logged the activity
    
    # Relationships
    lead = relationship("Lead", back_populates="activities")
