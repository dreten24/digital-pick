from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, Float, ForeignKey, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base
import enum

class ServiceStatus(enum.Enum):
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    RESCHEDULED = "rescheduled"

class Service(Base):
    __tablename__ = "services"

    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("businesses.id"), nullable=False)
    
    # Service details
    name = Column(String, nullable=False)
    category = Column(String, nullable=False)  # junk_removal, roofing, etc
    description = Column(Text)
    base_price = Column(Float)
    price_per_hour = Column(Float)
    estimated_duration_hours = Column(Float)
    
    # Service parameters
    requires_quote = Column(Boolean, default=True)
    requires_site_visit = Column(Boolean, default=False)
    can_schedule_online = Column(Boolean, default=True)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    business = relationship("Business", back_populates="services")
    service_requests = relationship("ServiceRequest", back_populates="service")

class ServiceRequest(Base):
    __tablename__ = "service_requests"

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    service_id = Column(Integer, ForeignKey("services.id"), nullable=False)
    
    # Request details
    status = Column(Enum(ServiceStatus), default=ServiceStatus.SCHEDULED)
    priority = Column(String, default="medium")
    
    # Scheduling
    requested_date = Column(DateTime)
    scheduled_start = Column(DateTime)
    scheduled_end = Column(DateTime)
    actual_start = Column(DateTime)
    actual_end = Column(DateTime)
    
    # Service team
    assigned_team = Column(String)
    team_size = Column(Integer, default=1)
    
    # Pricing
    quoted_price = Column(Float)
    final_price = Column(Float)
    hours_worked = Column(Float)
    
    # Service details
    work_description = Column(Text)
    materials_used = Column(Text)
    equipment_used = Column(Text)
    
    # Customer satisfaction
    customer_rating = Column(Integer)  # 1-5 stars
    customer_feedback = Column(Text)
    
    # Photos/documentation
    before_photos = Column(Text)  # JSON array of photo URLs
    after_photos = Column(Text)  # JSON array of photo URLs
    
    # Completion notes
    completion_notes = Column(Text)
    follow_up_required = Column(Boolean, default=False)
    follow_up_date = Column(DateTime)
    warranty_expires = Column(DateTime)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    lead = relationship("Lead", back_populates="service_requests")
    service = relationship("Service", back_populates="service_requests")
