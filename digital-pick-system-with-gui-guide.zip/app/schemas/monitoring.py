from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class MonitoringEventBase(BaseModel):
    event_type: str
    event_category: str
    title: str
    description: Optional[str] = None
    severity: str = "info"
    metadata: Optional[Dict[str, Any]] = None

class MonitoringEventCreate(MonitoringEventBase):
    business_id: Optional[int] = None
    source_module: Optional[str] = None
    source_function: Optional[str] = None
    user_id: Optional[int] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None

class MonitoringEventResponse(MonitoringEventBase):
    id: int
    business_id: Optional[int] = None
    source_module: Optional[str] = None
    source_function: Optional[str] = None
    user_id: Optional[int] = None
    is_resolved: bool
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class SystemMetricBase(BaseModel):
    metric_name: str
    metric_type: str
    metric_category: str
    value: float
    unit: Optional[str] = None
    tags: Optional[Dict[str, Any]] = None

class SystemMetricCreate(SystemMetricBase):
    business_id: Optional[int] = None
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    period_type: str = "point"

class SystemMetricResponse(SystemMetricBase):
    id: int
    business_id: Optional[int] = None
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    period_type: str
    recorded_at: datetime

    class Config:
        from_attributes = True
