from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.models.service import ServiceStatus

class ServiceBase(BaseModel):
    name: str
    category: str
    description: Optional[str] = None
    base_price: Optional[float] = None
    price_per_hour: Optional[float] = None
    estimated_duration_hours: Optional[float] = None
    requires_quote: bool = True
    requires_site_visit: bool = False
    can_schedule_online: bool = True

class ServiceCreate(ServiceBase):
    business_id: int

class ServiceUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    base_price: Optional[float] = None
    price_per_hour: Optional[float] = None
    estimated_duration_hours: Optional[float] = None
    requires_quote: Optional[bool] = None
    requires_site_visit: Optional[bool] = None
    can_schedule_online: Optional[bool] = None
    is_active: Optional[bool] = None

class ServiceResponse(ServiceBase):
    id: int
    business_id: int
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class ServiceRequestBase(BaseModel):
    priority: str = "medium"
    requested_date: Optional[datetime] = None
    work_description: Optional[str] = None
    assigned_team: Optional[str] = None
    team_size: int = 1

class ServiceRequestCreate(ServiceRequestBase):
    lead_id: int
    service_id: int

class ServiceRequestUpdate(BaseModel):
    status: Optional[ServiceStatus] = None
    priority: Optional[str] = None
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    actual_start: Optional[datetime] = None
    actual_end: Optional[datetime] = None
    assigned_team: Optional[str] = None
    team_size: Optional[int] = None
    quoted_price: Optional[float] = None
    final_price: Optional[float] = None
    hours_worked: Optional[float] = None
    work_description: Optional[str] = None
    materials_used: Optional[str] = None
    equipment_used: Optional[str] = None
    customer_rating: Optional[int] = None
    customer_feedback: Optional[str] = None
    before_photos: Optional[str] = None
    after_photos: Optional[str] = None
    completion_notes: Optional[str] = None
    follow_up_required: Optional[bool] = None
    follow_up_date: Optional[datetime] = None
    warranty_expires: Optional[datetime] = None

class ServiceRequestResponse(ServiceRequestBase):
    id: int
    lead_id: int
    service_id: int
    status: ServiceStatus
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    actual_start: Optional[datetime] = None
    actual_end: Optional[datetime] = None
    quoted_price: Optional[float] = None
    final_price: Optional[float] = None
    hours_worked: Optional[float] = None
    materials_used: Optional[str] = None
    equipment_used: Optional[str] = None
    customer_rating: Optional[int] = None
    customer_feedback: Optional[str] = None
    before_photos: Optional[str] = None
    after_photos: Optional[str] = None
    completion_notes: Optional[str] = None
    follow_up_required: bool
    follow_up_date: Optional[datetime] = None
    warranty_expires: Optional[datetime] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
