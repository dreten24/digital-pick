from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class BusinessBase(BaseModel):
    name: str
    business_type: str
    email: EmailStr
    phone: str
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    website: Optional[str] = None
    description: Optional[str] = None
    logo_url: Optional[str] = None
    service_radius: float = 25.0

class BusinessCreate(BusinessBase):
    pass

class BusinessUpdate(BaseModel):
    name: Optional[str] = None
    business_type: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    website: Optional[str] = None
    description: Optional[str] = None
    logo_url: Optional[str] = None
    service_radius: Optional[float] = None
    is_active: Optional[bool] = None
    subscription_status: Optional[str] = None

class BusinessResponse(BusinessBase):
    id: int
    is_active: bool
    subscription_status: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
