from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime
from app.models.lead import LeadSource, LeadStatus

class LeadBase(BaseModel):
    first_name: str
    last_name: str
    email: Optional[EmailStr] = None
    phone: str
    service_address: str
    service_city: str
    service_state: str
    service_zip: str
    source: LeadSource
    service_type: str
    description: Optional[str] = None
    urgency: str = "medium"
    estimated_value: Optional[float] = None
    preferred_date: Optional[datetime] = None

class LeadCreate(LeadBase):
    business_id: int

class LeadUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    service_address: Optional[str] = None
    service_city: Optional[str] = None
    service_state: Optional[str] = None
    service_zip: Optional[str] = None
    status: Optional[LeadStatus] = None
    service_type: Optional[str] = None
    description: Optional[str] = None
    urgency: Optional[str] = None
    estimated_value: Optional[float] = None
    quoted_amount: Optional[float] = None
    final_amount: Optional[float] = None
    preferred_date: Optional[datetime] = None
    scheduled_date: Optional[datetime] = None
    completed_date: Optional[datetime] = None
    is_priority: Optional[bool] = None
    follow_up_date: Optional[datetime] = None

class LeadResponse(LeadBase):
    id: int
    business_id: int
    status: LeadStatus
    quoted_amount: Optional[float] = None
    final_amount: Optional[float] = None
    scheduled_date: Optional[datetime] = None
    completed_date: Optional[datetime] = None
    first_contact_date: Optional[datetime] = None
    last_contact_date: Optional[datetime] = None
    follow_up_date: Optional[datetime] = None
    is_priority: bool
    is_recurring_customer: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class LeadActivityBase(BaseModel):
    activity_type: str
    description: str
    outcome: Optional[str] = None
    contact_method: Optional[str] = None
    duration_minutes: Optional[int] = None
    scheduled_at: Optional[datetime] = None

class LeadActivityCreate(LeadActivityBase):
    lead_id: int
    created_by: str

class LeadActivityResponse(LeadActivityBase):
    id: int
    lead_id: int
    completed_at: datetime
    created_by: str

    class Config:
        from_attributes = True
