from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.models.service import ServiceStatus
from app.schemas.service import ServiceCreate, ServiceUpdate, ServiceResponse, ServiceRequestCreate, ServiceRequestUpdate, ServiceRequestResponse
from app.services.service_service import ServiceService

router = APIRouter()
service_service = ServiceService()

# Service Management Endpoints
@router.post("/", response_model=ServiceResponse, status_code=status.HTTP_201_CREATED)
async def create_service(
    service: ServiceCreate,
    db: Session = Depends(get_db)
):
    """Create a new service offering"""
    return await service_service.create_service(db, service)

@router.get("/", response_model=List[ServiceResponse])
async def get_services(
    business_id: Optional[int] = None,
    category: Optional[str] = None,
    is_active: Optional[bool] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Get services with filtering"""
    return await service_service.get_services(db, business_id, category, is_active, skip, limit)

@router.get("/{service_id}", response_model=ServiceResponse)
async def get_service(service_id: int, db: Session = Depends(get_db)):
    """Get a specific service by ID"""
    service = await service_service.get_service(db, service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    return service

@router.put("/{service_id}", response_model=ServiceResponse)
async def update_service(
    service_id: int,
    service_update: ServiceUpdate,
    db: Session = Depends(get_db)
):
    """Update a service"""
    service = await service_service.update_service(db, service_id, service_update)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    return service

@router.delete("/{service_id}")
async def delete_service(service_id: int, db: Session = Depends(get_db)):
    """Delete a service (soft delete)"""
    success = await service_service.delete_service(db, service_id)
    if not success:
        raise HTTPException(status_code=404, detail="Service not found")
    return {"message": "Service deactivated successfully"}

# Service Request Endpoints
@router.post("/requests", response_model=ServiceRequestResponse, status_code=status.HTTP_201_CREATED)
async def create_service_request(
    request: ServiceRequestCreate,
    db: Session = Depends(get_db)
):
    """Create a new service request"""
    return await service_service.create_service_request(db, request)

@router.get("/requests", response_model=List[ServiceRequestResponse])
async def get_service_requests(
    business_id: Optional[int] = None,
    status: Optional[ServiceStatus] = None,
    priority: Optional[str] = None,
    assigned_team: Optional[str] = None,
    scheduled_after: Optional[datetime] = None,
    scheduled_before: Optional[datetime] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Get service requests with filtering"""
    return await service_service.get_service_requests(
        db, business_id, status, priority, assigned_team,
        scheduled_after, scheduled_before, skip, limit
    )

@router.get("/requests/{request_id}", response_model=ServiceRequestResponse)
async def get_service_request(request_id: int, db: Session = Depends(get_db)):
    """Get a specific service request by ID"""
    request = await service_service.get_service_request(db, request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Service request not found")
    return request

@router.put("/requests/{request_id}", response_model=ServiceRequestResponse)
async def update_service_request(
    request_id: int,
    request_update: ServiceRequestUpdate,
    db: Session = Depends(get_db)
):
    """Update a service request"""
    request = await service_service.update_service_request(db, request_id, request_update)
    if not request:
        raise HTTPException(status_code=404, detail="Service request not found")
    return request

@router.post("/requests/{request_id}/start")
async def start_service(
    request_id: int,
    start_time: Optional[datetime] = None,
    db: Session = Depends(get_db)
):
    """Mark a service as started"""
    success = await service_service.start_service(db, request_id, start_time)
    if not success:
        raise HTTPException(status_code=404, detail="Service request not found")
    return {"message": "Service started successfully"}

@router.post("/requests/{request_id}/complete")
async def complete_service(
    request_id: int,
    completion_data: dict,
    db: Session = Depends(get_db)
):
    """Mark a service as completed with completion data"""
    success = await service_service.complete_service(db, request_id, completion_data)
    if not success:
        raise HTTPException(status_code=404, detail="Service request not found")
    return {"message": "Service completed successfully"}

@router.get("/requests/{request_id}/timeline")
async def get_service_timeline(request_id: int, db: Session = Depends(get_db)):
    """Get timeline of a service request"""
    timeline = await service_service.get_service_timeline(db, request_id)
    if not timeline:
        raise HTTPException(status_code=404, detail="Service request not found")
    return timeline

@router.get("/analytics/performance")
async def get_service_performance(
    business_id: Optional[int] = None,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get service performance analytics"""
    return await service_service.get_performance_analytics(db, business_id, days)

@router.get("/analytics/revenue")
async def get_service_revenue(
    business_id: Optional[int] = None,
    days: int = Query(30, ge=1, le=365),
    service_category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get service revenue analytics"""
    return await service_service.get_revenue_analytics(db, business_id, days, service_category)

@router.get("/requests/schedule/today")
async def get_todays_schedule(
    business_id: int,
    team: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get today's service schedule"""
    return await service_service.get_daily_schedule(db, business_id, team)

@router.get("/requests/schedule/week")
async def get_weekly_schedule(
    business_id: int,
    team: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get this week's service schedule"""
    return await service_service.get_weekly_schedule(db, business_id, team)
