from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime, timedelta

from app.core.database import get_db
from app.services.dashboard_service import DashboardService

router = APIRouter()
dashboard_service = DashboardService()

@router.get("/{business_id}/overview")
async def get_dashboard_overview(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Get business dashboard overview"""
    return await dashboard_service.get_overview(db, business_id, period)

@router.get("/{business_id}/leads/metrics")
async def get_lead_metrics(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Get detailed lead metrics"""
    return await dashboard_service.get_lead_metrics(db, business_id, period)

@router.get("/{business_id}/revenue/analytics")
async def get_revenue_analytics(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    group_by: str = Query("day", regex="^(hour|day|week|month)$"),
    db: Session = Depends(get_db)
):
    """Get revenue analytics with time grouping"""
    return await dashboard_service.get_revenue_analytics(db, business_id, period, group_by)

@router.get("/{business_id}/services/performance")
async def get_service_performance(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Get service performance metrics"""
    return await dashboard_service.get_service_performance(db, business_id, period)

@router.get("/{business_id}/conversion/funnel")
async def get_conversion_funnel(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Get conversion funnel analysis"""
    return await dashboard_service.get_conversion_funnel(db, business_id, period)

@router.get("/{business_id}/team/performance")
async def get_team_performance(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Get team performance metrics"""
    return await dashboard_service.get_team_performance(db, business_id, period)

@router.get("/{business_id}/forecast")
async def get_revenue_forecast(
    business_id: int,
    forecast_days: int = Query(30, ge=7, le=90),
    db: Session = Depends(get_db)
):
    """Get revenue forecast based on historical data"""
    return await dashboard_service.get_revenue_forecast(db, business_id, forecast_days)

@router.get("/{business_id}/alerts")
async def get_business_alerts(
    business_id: int,
    severity: Optional[str] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get business-specific alerts and notifications"""
    return await dashboard_service.get_business_alerts(db, business_id, severity, category)

@router.get("/{business_id}/kpis")
async def get_key_performance_indicators(
    business_id: int,
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Get key performance indicators"""
    return await dashboard_service.get_kpis(db, business_id, period)

@router.get("/{business_id}/export")
async def export_dashboard_data(
    business_id: int,
    format: str = Query("json", regex="^(json|csv|xlsx)$"),
    period: str = Query("30d", regex="^(24h|7d|30d|90d)$"),
    include_leads: bool = True,
    include_services: bool = True,
    include_revenue: bool = True,
    db: Session = Depends(get_db)
):
    """Export dashboard data in various formats"""
    return await dashboard_service.export_data(
        db, business_id, format, period, include_leads, include_services, include_revenue
    )
