from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.schemas.monitoring import MonitoringEventCreate, MonitoringEventResponse, SystemMetricCreate, SystemMetricResponse
from app.services.monitoring_service import MonitoringService

router = APIRouter()
monitoring_service = MonitoringService()

@router.post("/events", response_model=MonitoringEventResponse, status_code=201)
async def create_event(
    event: MonitoringEventCreate,
    db: Session = Depends(get_db)
):
    """Create a monitoring event"""
    return await monitoring_service.create_event(db, event)

@router.get("/events", response_model=List[MonitoringEventResponse])
async def get_events(
    business_id: Optional[int] = None,
    event_category: Optional[str] = None,
    severity: Optional[str] = None,
    is_resolved: Optional[bool] = None,
    created_after: Optional[datetime] = None,
    created_before: Optional[datetime] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Get monitoring events with filtering"""
    return await monitoring_service.get_events(
        db, business_id, event_category, severity, is_resolved,
        created_after, created_before, skip, limit
    )

@router.post("/metrics", response_model=SystemMetricResponse, status_code=201)
async def create_metric(
    metric: SystemMetricCreate,
    db: Session = Depends(get_db)
):
    """Record a system metric"""
    return await monitoring_service.create_metric(db, metric)

@router.get("/metrics", response_model=List[SystemMetricResponse])
async def get_metrics(
    business_id: Optional[int] = None,
    metric_name: Optional[str] = None,
    metric_category: Optional[str] = None,
    recorded_after: Optional[datetime] = None,
    recorded_before: Optional[datetime] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Get system metrics with filtering"""
    return await monitoring_service.get_metrics(
        db, business_id, metric_name, metric_category,
        recorded_after, recorded_before, skip, limit
    )

@router.get("/health")
async def get_system_health():
    """Get overall system health status"""
    return await monitoring_service.get_system_health()

@router.get("/dashboard/{business_id}")
async def get_business_dashboard(
    business_id: int,
    period: str = Query("24h", regex="^(1h|24h|7d|30d)$"),
    db: Session = Depends(get_db)
):
    """Get business dashboard data"""
    return await monitoring_service.get_business_dashboard(db, business_id, period)

@router.get("/alerts")
async def get_active_alerts(
    business_id: Optional[int] = None,
    severity: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get active system alerts"""
    return await monitoring_service.get_active_alerts(db, business_id, severity)

@router.post("/events/{event_id}/resolve")
async def resolve_event(
    event_id: int,
    resolved_by: str,
    resolution_notes: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Mark an event as resolved"""
    success = await monitoring_service.resolve_event(db, event_id, resolved_by, resolution_notes)
    if not success:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"message": "Event resolved successfully"}
