from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.models.lead import Lead, LeadSource, LeadStatus
from app.schemas.lead import LeadCreate, LeadUpdate, LeadResponse, LeadActivityCreate, LeadActivityResponse
from app.services.lead_service import LeadService
from app.services.notification_service import NotificationService

router = APIRouter()
lead_service = LeadService()
notification_service = NotificationService()

@router.post("/", response_model=LeadResponse, status_code=status.HTTP_201_CREATED)
async def create_lead(
    lead: LeadCreate,
    db: Session = Depends(get_db)
):
    """Create a new lead"""
    try:
        new_lead = await lead_service.create_lead(db, lead)
        
        # Send notification for new lead
        await notification_service.notify_new_lead(new_lead)
        
        return new_lead
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/", response_model=List[LeadResponse])
async def get_leads(
    business_id: Optional[int] = None,
    status: Optional[LeadStatus] = None,
    source: Optional[LeadSource] = None,
    urgency: Optional[str] = None,
    is_priority: Optional[bool] = None,
    created_after: Optional[datetime] = None,
    created_before: Optional[datetime] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Get leads with comprehensive filtering"""
    return await lead_service.get_leads(
        db, business_id, status, source, urgency, is_priority,
        created_after, created_before, skip, limit
    )

@router.get("/{lead_id}", response_model=LeadResponse)
async def get_lead(lead_id: int, db: Session = Depends(get_db)):
    """Get a specific lead by ID"""
    lead = await lead_service.get_lead(db, lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return lead

@router.put("/{lead_id}", response_model=LeadResponse)
async def update_lead(
    lead_id: int,
    lead_update: LeadUpdate,
    db: Session = Depends(get_db)
):
    """Update a lead"""
    lead = await lead_service.update_lead(db, lead_id, lead_update)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    # Send notification for status changes
    if lead_update.status:
        await notification_service.notify_lead_status_change(lead, lead_update.status)
    
    return lead

@router.delete("/{lead_id}")
async def delete_lead(lead_id: int, db: Session = Depends(get_db)):
    """Delete a lead"""
    success = await lead_service.delete_lead(db, lead_id)
    if not success:
        raise HTTPException(status_code=404, detail="Lead not found")
    return {"message": "Lead deleted successfully"}

@router.post("/{lead_id}/activities", response_model=LeadActivityResponse, status_code=status.HTTP_201_CREATED)
async def create_lead_activity(
    lead_id: int,
    activity: LeadActivityCreate,
    db: Session = Depends(get_db)
):
    """Add an activity to a lead"""
    activity.lead_id = lead_id
    return await lead_service.create_activity(db, activity)

@router.get("/{lead_id}/activities", response_model=List[LeadActivityResponse])
async def get_lead_activities(
    lead_id: int,
    db: Session = Depends(get_db)
):
    """Get all activities for a lead"""
    return await lead_service.get_activities(db, lead_id)

@router.put("/{lead_id}/convert")
async def convert_lead(
    lead_id: int,
    service_id: int,
    quoted_amount: Optional[float] = None,
    scheduled_date: Optional[datetime] = None,
    db: Session = Depends(get_db)
):
    """Convert a lead to a service request"""
    result = await lead_service.convert_to_service(
        db, lead_id, service_id, quoted_amount, scheduled_date
    )
    if not result:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    return {"message": "Lead converted to service request", "service_request_id": result}

@router.get("/{lead_id}/timeline")
async def get_lead_timeline(lead_id: int, db: Session = Depends(get_db)):
    """Get complete timeline of a lead including activities and status changes"""
    timeline = await lead_service.get_lead_timeline(db, lead_id)
    if not timeline:
        raise HTTPException(status_code=404, detail="Lead not found")
    return timeline

@router.post("/{lead_id}/follow-up")
async def schedule_follow_up(
    lead_id: int,
    follow_up_date: datetime,
    notes: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Schedule a follow-up for a lead"""
    success = await lead_service.schedule_follow_up(db, lead_id, follow_up_date, notes)
    if not success:
        raise HTTPException(status_code=404, detail="Lead not found")
    return {"message": "Follow-up scheduled successfully"}

@router.get("/analytics/conversion-rates")
async def get_conversion_rates(
    business_id: Optional[int] = None,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get lead conversion analytics"""
    return await lead_service.get_conversion_analytics(db, business_id, days)

@router.get("/analytics/source-performance")
async def get_source_performance(
    business_id: Optional[int] = None,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get lead source performance analytics"""
    return await lead_service.get_source_analytics(db, business_id, days)
