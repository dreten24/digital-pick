from fastapi import APIRouter, Request, HTTPException, Header, BackgroundTasks
from typing import Optional
import hmac
import hashlib
import json

from app.core.config import settings
from app.webhooks.handlers import WebhookHandlers
from app.services.lead_service import LeadService

router = APIRouter()
webhook_handlers = WebhookHandlers()
lead_service = LeadService()

def verify_webhook_signature(payload: bytes, signature: str, secret: str) -> bool:
    """Verify webhook signature"""
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(f"sha256={expected_signature}", signature)

@router.post("/lead-capture")
async def lead_capture_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_signature: Optional[str] = Header(None, alias="X-Signature")
):
    """Webhook for capturing leads from external sources"""
    body = await request.body()
    
    # Verify signature if provided
    if x_signature and settings.webhook_secret:
        if not verify_webhook_signature(body, x_signature, settings.webhook_secret):
            raise HTTPException(status_code=401, detail="Invalid signature")
    
    try:
        data = json.loads(body)
        background_tasks.add_task(webhook_handlers.handle_lead_capture, data)
        return {"status": "accepted", "message": "Lead capture webhook received"}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

@router.post("/form-submission")
async def form_submission_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_signature: Optional[str] = Header(None, alias="X-Signature")
):
    """Webhook for form submissions from websites"""
    body = await request.body()
    
    if x_signature and settings.webhook_secret:
        if not verify_webhook_signature(body, x_signature, settings.webhook_secret):
            raise HTTPException(status_code=401, detail="Invalid signature")
    
    try:
        data = json.loads(body)
        background_tasks.add_task(webhook_handlers.handle_form_submission, data)
        return {"status": "accepted", "message": "Form submission webhook received"}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

@router.post("/google-ads")
async def google_ads_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    authorization: Optional[str] = Header(None)
):
    """Webhook for Google Ads lead notifications"""
    body = await request.body()
    
    try:
        data = json.loads(body)
        background_tasks.add_task(webhook_handlers.handle_google_ads_lead, data)
        return {"status": "accepted", "message": "Google Ads webhook received"}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

@router.post("/facebook-leads")
async def facebook_leads_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_hub_signature: Optional[str] = Header(None, alias="X-Hub-Signature-256")
):
    """Webhook for Facebook lead ads"""
    body = await request.body()
    
    # Verify Facebook signature
    if x_hub_signature and settings.webhook_secret:
        if not verify_webhook_signature(body, x_hub_signature, settings.webhook_secret):
            raise HTTPException(status_code=401, detail="Invalid signature")
    
    try:
        data = json.loads(body)
        background_tasks.add_task(webhook_handlers.handle_facebook_lead, data)
        return {"status": "accepted", "message": "Facebook lead webhook received"}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

@router.get("/facebook-leads")
async def facebook_webhook_verification(
    hub_mode: str = None,
    hub_challenge: str = None,
    hub_verify_token: str = None
):
    """Facebook webhook verification"""
    if hub_mode == "subscribe" and hub_verify_token == settings.webhook_secret:
        return int(hub_challenge)
    raise HTTPException(status_code=400, detail="Invalid verification token")

@router.post("/payment-update")
async def payment_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    stripe_signature: Optional[str] = Header(None, alias="Stripe-Signature")
):
    """Webhook for payment updates from Stripe"""
    body = await request.body()
    
    try:
        data = json.loads(body)
        background_tasks.add_task(webhook_handlers.handle_payment_update, data)
        return {"status": "accepted", "message": "Payment webhook received"}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

@router.post("/status-update")
async def status_update_webhook(
    request: Request,
    background_tasks: BackgroundTasks
):
    """Generic webhook for status updates"""
    body = await request.body()
    
    try:
        data = json.loads(body)
        background_tasks.add_task(webhook_handlers.handle_status_update, data)
        return {"status": "accepted", "message": "Status update webhook received"}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")
