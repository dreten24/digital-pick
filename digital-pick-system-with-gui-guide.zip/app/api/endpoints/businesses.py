from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta

from app.core.database import get_db
from app.models.business import Business
from app.schemas.business import BusinessCreate, BusinessUpdate, BusinessResponse
from app.services.business_service import BusinessService

router = APIRouter()
business_service = BusinessService()

@router.post("/", response_model=BusinessResponse, status_code=status.HTTP_201_CREATED)
async def create_business(
    business: BusinessCreate,
    db: Session = Depends(get_db)
):
    """Create a new business account"""
    try:
        return await business_service.create_business(db, business)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/", response_model=List[BusinessResponse])
async def get_businesses(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    is_active: Optional[bool] = None,
    business_type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get all businesses with optional filtering"""
    return await business_service.get_businesses(db, skip, limit, is_active, business_type)

@router.get("/{business_id}", response_model=BusinessResponse)
async def get_business(business_id: int, db: Session = Depends(get_db)):
    """Get a specific business by ID"""
    business = await business_service.get_business(db, business_id)
    if not business:
        raise HTTPException(status_code=404, detail="Business not found")
    return business

@router.put("/{business_id}", response_model=BusinessResponse)
async def update_business(
    business_id: int,
    business_update: BusinessUpdate,
    db: Session = Depends(get_db)
):
    """Update a business"""
    business = await business_service.update_business(db, business_id, business_update)
    if not business:
        raise HTTPException(status_code=404, detail="Business not found")
    return business

@router.delete("/{business_id}")
async def delete_business(business_id: int, db: Session = Depends(get_db)):
    """Delete a business (soft delete - deactivate)"""
    success = await business_service.delete_business(db, business_id)
    if not success:
        raise HTTPException(status_code=404, detail="Business not found")
    return {"message": "Business deactivated successfully"}

@router.get("/{business_id}/stats")
async def get_business_stats(business_id: int, db: Session = Depends(get_db)):
    """Get comprehensive business statistics"""
    stats = await business_service.get_business_stats(db, business_id)
    if not stats:
        raise HTTPException(status_code=404, detail="Business not found")
    return stats

@router.get("/{business_id}/leads/summary")
async def get_leads_summary(
    business_id: int,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get lead summary statistics for a business"""
    summary = await business_service.get_leads_summary(db, business_id, days)
    return summary

@router.get("/{business_id}/revenue/summary")
async def get_revenue_summary(
    business_id: int,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """Get revenue summary for a business"""
    summary = await business_service.get_revenue_summary(db, business_id, days)
    return summary
