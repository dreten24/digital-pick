from fastapi import APIRouter
from app.api.endpoints import businesses, leads, services, users, monitoring, webhooks, dashboard

router = APIRouter()

# Include all endpoint routers
router.include_router(businesses.router, prefix="/businesses", tags=["businesses"])
router.include_router(leads.router, prefix="/leads", tags=["leads"])
router.include_router(services.router, prefix="/services", tags=["services"])
router.include_router(users.router, prefix="/users", tags=["users"])
router.include_router(monitoring.router, prefix="/monitoring", tags=["monitoring"])
router.include_router(webhooks.router, prefix="/webhooks", tags=["webhooks"])
router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
